<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Request Form Table</title>

    <style>
          @import url('https://fonts.googleapis.com/css2?family=Mulish:wght@300;400;500;600;700;800&display=swap');

        *{
            margin:0;
            padding:0;
            box-sizing: border-box;
            font-family: 'Mulish', sans-serif;
        }

        h1{
            text-align: center;
            padding-top: 2rem;
            font-weight: 700;   
        }

        .d_grid{
            display:flex;
            justify-content:center;
            align-items:center;
            gap:0;
            padding: 3rem;
        }

        table, td, th {  
            border: 1px solid #ddd;
            text-align: left;
        }

        table {
            border-collapse: collapse;
            width: 100%;
            background-color: #000;
            color: #fff;
        }

        th, td {
          padding: 15px;
        }

        td:first-of-type{
            text-transform: capitalize;
            /* background-color: red; */
        }

        button{
            border: 0;
            height: 2rem;
            width: 7rem;
            padding: 0 ;
            font-size: .8rem;
            font-weight: 700;
            cursor: pointer;
            border-radius: 0.1rem;
        }

        button a{
            color: #000;
            text-decoration: none;
        }
        /* @media (max-width:991px){} */

    </style>
</head>

<body>
    <h1>Booking Request</h1>
    <div class="d_grid">

     
        
<table>
    <tr>
      <th >Name</th>
      <th>Phone</th>
      <th>Email Id</th>
      <th>Pick UP Adderss</th>
      <th>Destination</th>
      <th>DD/Month/Year</th>
      <th>Message</th>
      <th></th>
    </tr>
    

    <!-- 1st content -->
    <tr>
        <td>Raj Kumar</td>
        <td>66678877555</td>
        <td>raj@gmail.com</td>
        <td>patna</td>
        <td>Gaya</td>
        <td>04/04/2022</td>
        <td>Hello satyam travel</td> 
        <td><button type="submit" value="submit" name="submit">
            <a href="tel:66678877555">Booking Conform</a>
            </button>
        </td>
    </tr>

    <!-- 2st content -->
    <tr>
        <td>rajesh Kumar</td>
        <td>66678877555</td>
        <td>rajesh@gmail.com</td>
        <td>patna</td>
        <td>Gaya</td>
        <td>04/04/2022</td>
        <td>Hello satyam travel</td> 
        <td><button type="submit" value="submit" name="submit">
            <a href="tel:66678877555">Booking Conform</a>
            </button>
        </td>
    </tr>
    
    <!-- 3rd content -->

    <tr>
        <td>Jyoti Kumari</td>
        <td>66678877555</td>
        <td>jyoti@gmail.com</td>
        <td>patna</td>
        <td>Gaya</td>
        <td>04/04/2022</td>
        <td>Hello satyam travel</td> 
        <td><button type="submit" value="submit" name="submit">
            <a href="tel:66678877555">Booking Conform</a>
            </button>
        </td>
    </tr>
    </div>
</body>
</html>

<!-- 
<tr>
    <td>Peter</td>
    <td>Griffin</td>
    <td>$100</td>
  </tr>

  <tr>
    <td>Lois</td>
    <td>Griffin</td>
    <td>$150</td>
  </tr>
  
  <tr>
    <td>Joe</td>
    <td>Swanson</td>
    <td>$300</td>
  </tr>

  <tr>
    <td>Cleveland</td>
    <td>Brown</td>
    <td>$250</td>
  </tr> -->
