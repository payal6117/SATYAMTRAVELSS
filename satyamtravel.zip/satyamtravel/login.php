<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Login</title>
    
    <style>
       @import url('https://fonts.googleapis.com/css2?family=Mulish:wght@300;400;500;600;700;800&display=swap');

*{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

html{
    font-size: 52.6%;
}

body{
    text-transform: capitalize;
    font-family: 'Mulish', sans-serif;
    color: #000000;
    background-color: #ffffff;
}

ul, li, a{
    padding: 0;
    text-decoration: none;
    list-style: none;
}

.btn{
    width: 100%;
    height: auto;
    display: flex;
    justify-content: center;
    padding-left: 0;
    margin-top: 2.4rem;
    margin-bottom: 1rem;
}

button { 
    width: 21rem;
    height: 3.7rem;
    border: 1px solid rgb(226, 226, 10);
    border-radius: 2rem;
    font-size: 1.5rem;
    font-weight: 700;
    word-spacing: .2rem;
    outline: none;   
    text-transform: uppercase;
    color: #000000;
    background-color: transparent;
    box-shadow: 0px 8px 15px #b9182023;
    font-family: 'Montserrat', sans-serif;
    cursor: pointer;
}

button:hover{
    background-color:rgb(226, 226, 10) ;
    color: #000000;
}


@media (max-width:991px){

    .btn{
        width: 100%;
        height: auto;
    }
    
    button { 
        width: 11rem;
        height: 3.3rem;
    }
    
}

.welcome__you{
    width: 100%;
    height: 100vh;
    background-color: transparent; 
}

.welcome_you__items{
    display: grid;
    grid-template-columns: 1.3fr 1fr;
    grid-template-rows: 100vh;
    gap: 0px;
}

.welcome_you_item__1{
    background-color: #000000;
    width: 100%;
    height: auto;
    padding: 0 ;
}

.welcome_you_item__1 img{
    width: 100%;
    height: 68.5rem;
    object-fit: cover;
    object-position: cover;
}

.welcome_you_item__2{
    /* background-color: red; */
    padding-top: 11rem;
}

.login{
    font-size: 3.4rem;
    font-weight: 700;
    padding: 3rem 0;
    text-align: center;
    text-transform: capitalize;
}

.welcome_you_item__2 form{
    width: 100%;
    height: auto;
    display: flex;
    justify-content: center;
    box-sizing: border-box;
}

.welcome_you_item__2 .form__input{
    width: 100%;
    height: auto;
    display: block  ;
}


.welcome_you_item__2 .form__input  input{
    width: 40rem;
    height: 5rem;
    margin-top: 1.2rem;
    border: .2rem solid rgb(226, 226, 10);
    border-radius: .5rem;
    padding-left: 1rem;
    font-size: 1.5rem;
    outline: none;
    text-transform: capitalize;
    letter-spacing: .1rem;
}

input::placeholder{
    color: #000000;
}

.welcome_you_item__2 a{
    font-size: 1.5rem;
    color: #13a8d1;
    font-weight: 500;
    box-sizing: border-box;
    display: flex;
    justify-content: center;
    padding-bottom: 7rem;
    
}

.welcome_you_item__2 #explore_our_product{
    padding-bottom: 0rem;
    font-size: 1.7rem;
    color: rgba(54, 54, 54, 0.815);
}
.welcome_you_item__2 .line__img{
    position: relative;
    display: flex;
    justify-content: center;
    padding: 1.7rem;
}

.welcome_you_item__2 .line__img img{
    width: 20%;
    height: .5rem;
}





@media (max-width:991px){
    .welcome__you{
        width: 100%;
        height: auto;
    }
    
    .welcome_you__items{
        display: block;
    }
    
    .welcome_you_item__1{
        width: 100%;
        height: auto;
        padding-left: 0;
        
    }

    .welcome_you_item__1 img{
    width: 100%;
    height: 18rem;
    object-fit: cover;
    object-position: cover;
}
    .welcome_you_item__2{
        padding-top: 0;
    }

    .login{
        font-size: 3.4rem;
        padding: 1.9rem 0;
        font-weight: 600;
    }
    
    .welcome_you_item__2 form{
        width: 100%;
        height: auto;
    }
    
    .welcome_you_item__2 .form__input{
        width: 100%;
        height: auto;
        display: block  ;
        padding:0  ;
    }
    
    
    .welcome_you_item__2 .form__input  input{
        width: 40rem;
        font-size: 1.3rem;
    }
    

}
    </style>

</head>
<body>
<section>
            <div class="welcome__you">
                <div class="welcome_you__items">
                    <div class="welcome_you_item__1">
                        <img src="./img/banner.jpg" alt="">
                    </div>
                    <div class="welcome_you_item__2">
                        <h1 class="login">User login</h1>

                        <form action="#">

                            <ul>
                                <div class="form__input">
                                    <li> 
                                        <div class="username">
                                            <input type="text" placeholder="username">
                                        </div>
                                    </li>
                                    <li> 
                                        <div class="userpass">
                                            <input type="text" placeholder="password">
                                        </div>
                                    </li>
                                </div>
                                
                                <div class="btn">
                                    <li>
                                        <button class="">log in</button>
                                    </li>
                                </div>
                                
                            </ul>
                        </form>

                        <div class="line__img">
                        <!-- <img src="imgs/line.png" alt="D3 classes"> -->
                        </div>
                    </div>
                </div>
            </div>
        </section>
</body>
</html>